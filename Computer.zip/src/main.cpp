#include "Computer.h"

int main() {
    Computer comp(100);
    comp.dump();

    return 0;
}